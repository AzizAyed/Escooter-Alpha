/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reclamGui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author aweld
 */
public class HomeController implements Initializable {

    @FXML
    private Button logout;
    @FXML
    private Button EXIT;
    @FXML
    private Button Reclamation;

   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

   @FXML
    public void EXIT (){
         System.exit(0);
        
    }

    void logout(ActionEvent event) throws IOException {
        Parent view4 = FXMLLoader.load(getClass().getResource("signin.fxml"));
        Scene scene4 = new Scene(view4);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene4);
        window.show();
    }

@FXML
    public void Reclamation(ActionEvent event) throws IOException {
        if (Reclamation.isFocused()) {
        Parent view4 = FXMLLoader.load(getClass().getResource("AjouterReclamation.fxml"));
        Scene scene4 = new Scene(view4);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene4);
        window.show();
        }
    }
}
